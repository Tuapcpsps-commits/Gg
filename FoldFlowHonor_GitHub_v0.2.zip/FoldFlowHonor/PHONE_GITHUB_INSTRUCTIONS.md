# Bouwen op GitHub vanaf je telefoon

Dit project bevat een GitHub Actions-workflow die automatisch een debug-APK bouwt.

## Zodra de bestanden in een GitHub-repository staan
1. Open de repository op GitHub.
2. Open **Actions**.
3. Kies **Build FoldFlow Honor APK**.
4. Kies **Run workflow** en nogmaals **Run workflow**.
5. Open de afgeronde run.
6. Onder **Artifacts** staat **FoldFlowHonor-v0.2-debug-apk**.
7. Download het artifact en pak de ZIP uit op je Honor.
8. Installeer `app-debug.apk`.

De workflow draait ook automatisch na een push naar `main` of `master`.
