package nl.chris.foldflow;

import android.app.Activity;
import android.os.Bundle;
import android.hardware.*;
import android.graphics.*;
import android.view.*;
import android.content.*;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor hinge;
    private FoldView foldView;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.rgb(6, 8, 12));
        WindowInsetsController ctl = getWindow().getInsetsController();
        if (ctl != null) ctl.hide(WindowInsets.Type.statusBars());

        foldView = new FoldView(this);
        setContentView(foldView);

        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        hinge = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE);
        foldView.setSensorAvailable(hinge != null);
    }

    @Override protected void onResume() {
        super.onResume();
        if (hinge != null) sensorManager.registerListener(this, hinge, SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override protected void onPause() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        super.onPause();
    }

    @Override public void onSensorChanged(SensorEvent e) {
        if (e.sensor.getType() == Sensor.TYPE_HINGE_ANGLE && e.values.length > 0) {
            foldView.setRealAngle(e.values[0], e.timestamp);
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    static class FoldView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Vibrator vibrator;

        private float rawAngle = 180f;
        private float angle = 180f;
        private float velocity = 0f; // signed deg/sec, + opening, - closing
        private long lastSensorNs = 0L;
        private boolean sensorAvailable = false;
        private boolean manual = false;
        private boolean ticked = false;
        private boolean showDebug = true;
        private boolean frozen = false;
        private float manualAngle = 180f;

        FoldView(Context c) {
            super(c);
            setBackgroundColor(Color.rgb(6,8,12));
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            text.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            vibrator = (Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
        }

        void setSensorAvailable(boolean available) {
            sensorAvailable = available;
            invalidate();
        }

        void setRealAngle(float a, long timestampNs) {
            if (manual || frozen) return;
            rawAngle = clamp(a, 0f, 180f);

            if (lastSensorNs == 0L) {
                angle = rawAngle;
                lastSensorNs = timestampNs;
                invalidate();
                return;
            }

            float dt = clamp((timestampNs - lastSensorNs) / 1_000_000_000f, 0.001f, 0.08f);
            lastSensorNs = timestampNs;

            // Adaptive low-pass filter: stable when stationary, responsive while folding quickly.
            float delta = rawAngle - angle;
            float response = 0.20f + Math.min(0.62f, Math.abs(delta) / 34f);
            float next = angle + delta * response;
            velocity = (next - angle) / dt;
            angle = next;

            hapticAtMidpoint();
            invalidate();
        }

        private void setManualAngle(float a) {
            float next = clamp(a, 0f, 180f);
            velocity = (next - angle) * 20f;
            rawAngle = next;
            angle = next;
            manualAngle = next;
            hapticAtMidpoint();
            invalidate();
        }

        private void hapticAtMidpoint() {
            boolean nearMid = angle > 87f && angle < 93f;
            if (nearMid && !ticked) {
                ticked = true;
                if (vibrator != null && vibrator.hasVibrator()) {
                    vibrator.vibrate(VibrationEffect.createOneShot(9, 62));
                }
            } else if (angle < 78f || angle > 102f) {
                ticked = false;
            }
        }

        private float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
        private float smooth(float x) { x=clamp(x,0,1); return x*x*(3f-2f*x); }
        private float smoother(float x) { x=clamp(x,0,1); return x*x*x*(x*(x*6f-15f)+10f); }
        private int mix(int a, int b, float t) {
            t = clamp(t,0,1);
            return Color.rgb(
                    (int)(Color.red(a)+(Color.red(b)-Color.red(a))*t),
                    (int)(Color.green(a)+(Color.green(b)-Color.green(a))*t),
                    (int)(Color.blue(a)+(Color.blue(b)-Color.blue(a))*t));
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;

            // 0 = closed, 1 = completely flat. Keep endpoints quiet to avoid jitter.
            float open = smoother((angle - 6f) / 168f);
            float bend = (float)Math.sin(Math.PI * open); // strongest around 90°
            float speed = clamp(Math.abs(velocity) / 520f, 0f, 1f);
            float signedMotion = clamp(velocity / 650f, -1f, 1f);

            c.drawColor(mix(Color.rgb(4,6,11), Color.rgb(10,11,17), open));

            // Main glass surface subtly compresses while bent.
            float scaleX = 1f - 0.035f * bend;
            float scaleY = 1f - 0.012f * bend;
            c.save();
            c.scale(scaleX, scaleY, w/2f, h/2f);
            drawGlassSurface(c, w, h, open, bend, speed, signedMotion);
            c.restore();

            drawCrease(c, w, h, bend, open, signedMotion);
            drawHighlightSweep(c, w, h, bend, open, signedMotion);
            drawTelemetry(c, w, h, open, speed);
            drawControls(c, w, h);
        }

        private void drawGlassSurface(Canvas c, float w, float h, float open, float bend, float speed, float signedMotion) {
            float margin = dp(16);
            p.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{Color.rgb(23,33,53), Color.rgb(18,20,30), Color.rgb(8,10,15)},
                    new float[]{0f,.52f,1f}, Shader.TileMode.CLAMP));
            p.setAlpha(255);
            r.set(margin, margin, w-margin, h-margin);
            c.drawRoundRect(r, dp(34), dp(34), p);
            p.setShader(null);

            // Motion smear moves in opposite directions for cover and inside layers.
            float maxShift = Math.min(w*.10f, dp(42));
            float motionShift = signedMotion * maxShift * bend;
            float blurSpread = speed * dp(13) * bend;

            int coverAlpha = (int)(255 * (1f - smooth((open-.08f)/.70f)));
            int innerAlpha = (int)(255 * smooth((open-.20f)/.70f));

            if (coverAlpha > 2) {
                drawCover(c, w, h, motionShift, blurSpread, coverAlpha);
            }
            if (innerAlpha > 2) {
                drawInner(c, w, h, -motionShift*.75f, blurSpread*.65f, innerAlpha);
            }

            // Mild edge vignette increases around the middle of the fold.
            p.setShader(new RadialGradient(w/2f, h*.48f, Math.max(w,h)*.68f,
                    new int[]{Color.TRANSPARENT, Color.argb((int)(72*bend),0,0,0)}, null, Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);
            p.setShader(null);
        }

        private void drawCrease(Canvas c, float w, float h, float bend, float open, float signedMotion) {
            float cx = w/2f;
            float width = w * (.055f + .09f*bend);
            int shadowA = (int)(145*bend);
            p.setShader(new LinearGradient(cx-width,0,cx+width,0,
                    new int[]{Color.TRANSPARENT, Color.argb(shadowA,0,0,0), Color.argb((int)(32*bend),255,255,255), Color.TRANSPARENT},
                    new float[]{0f,.42f,.56f,1f}, Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);
            p.setShader(null);

            // Thin physical fold line, only visible when bent.
            p.setColor(Color.argb((int)(66*bend), 235,242,255));
            p.setStrokeWidth(Math.max(1f, dp(.7f)));
            c.drawLine(cx + signedMotion*dp(2), dp(18), cx + signedMotion*dp(2), h-dp(18), p);
        }

        private void drawHighlightSweep(Canvas c, float w, float h, float bend, float open, float signedMotion) {
            float base = w * (.12f + .76f*open);
            float sx = base + signedMotion*w*.08f*bend;
            int a = (int)(110*bend);
            p.setShader(new LinearGradient(sx-dp(120), h*.13f, sx+dp(120), h*.87f,
                    new int[]{Color.TRANSPARENT, Color.argb(a,235,246,255), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);
            p.setShader(null);
        }

        private void drawCover(Canvas c, float w, float h, float dx, float spread, int alpha) {
            c.save();
            c.translate(dx,0);
            float top=h*.17f;

            // ghost copies create cheap direction-aware motion blur without RenderEffect dependency
            int ghosts = spread > dp(2) ? 3 : 1;
            for (int g=ghosts-1; g>=0; g--) {
                float ghost = ghosts==1 ? 0f : (g/(float)(ghosts-1))*spread*(dx>=0?-1f:1f);
                int ga = g==0 ? alpha : (int)(alpha*.13f);
                c.save(); c.translate(ghost,0);
                p.setColor(Color.argb(ga,30,34,45));
                r.set(w*.12f,top,w*.88f,top+h*.13f); c.drawRoundRect(r,dp(28),dp(28),p);
                p.setColor(Color.argb(ga,242,242,246));
                r.set(w*.12f,top+h*.17f,w*.88f,top+h*.34f); c.drawRoundRect(r,dp(28),dp(28),p);
                p.setColor(Color.argb(ga,38,40,50));
                for(int i=0;i<4;i++){ float x=w*.17f+i*w*.19f; c.drawCircle(x,top+h*.45f,w*.055f,p); }
                c.restore();
            }

            text.setColor(Color.WHITE); text.setAlpha(alpha); text.setTextSize(dp(36)); text.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText("23:52",w*.12f,top-dp(24),text); text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(dp(13)); text.setAlpha((int)(alpha*.66f));
            c.drawText("FoldFlow • cover",w*.12f,top+dp(20),text);
            c.restore();
        }

        private void drawInner(Canvas c, float w, float h, float dx, float spread, int alpha) {
            c.save(); c.translate(dx,0);
            float m=w*.06f,g=w*.025f, cell=(w-2*m-3*g)/4f, top=h*.22f;
            int[] cols={0xff9db7ff,0xff6ee7b7,0xffffd166,0xffff8fab,0xffb197fc,0xff7bdff2,0xffffa552,0xff90dbf4};

            for(int row=0;row<2;row++) for(int col=0;col<4;col++){
                int i=row*4+col;
                int colr=cols[i];
                p.setColor(Color.argb((int)(220*(alpha/255f)), Color.red(colr),Color.green(colr),Color.blue(colr)));
                float x=m+col*(cell+g), y=top+row*(cell+g);
                r.set(x,y,x+cell,y+cell); c.drawRoundRect(r,dp(24),dp(24),p);
            }
            text.setColor(Color.WHITE); text.setAlpha(alpha); text.setTextSize(dp(39)); text.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText("FoldFlow",m,top-dp(42),text); text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(dp(13)); text.setAlpha((int)(alpha*.68f));
            c.drawText("Magic V6 • live hinge",m,top-dp(18),text);

            p.setColor(Color.argb((int)(82*(alpha/255f)),255,255,255));
            r.set(m,top+2*(cell+g)+dp(24),w-m,top+2*(cell+g)+dp(96)); c.drawRoundRect(r,dp(26),dp(26),p);
            c.restore();
        }

        private void drawTelemetry(Canvas c, float w, float h, float open, float speed) {
            if (!showDebug) return;
            float x=dp(22), y=dp(38);
            text.setColor(Color.WHITE); text.setAlpha(242); text.setTextSize(dp(25)); text.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(String.format(Locale.US,"%.1f°", rawAngle), x, y, text);
            text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(dp(12)); text.setAlpha(170);
            c.drawText(String.format(Locale.US,"smooth %.1f°   %+.0f°/s",angle,velocity),x,y+dp(20),text);
            c.drawText(sensorAvailable ? (manual?"HANDMATIG":"HONOR HINGE SENSOR • LIVE") : "HINGE SENSOR NIET BESCHIKBAAR",x,y+dp(38),text);

            // tiny live progress bar
            p.setColor(Color.argb(48,255,255,255));
            r.set(x,y+dp(50),x+dp(150),y+dp(54)); c.drawRoundRect(r,dp(2),dp(2),p);
            p.setColor(Color.argb(210,255,255,255));
            r.set(x,y+dp(50),x+dp(150)*open,y+dp(54)); c.drawRoundRect(r,dp(2),dp(2),p);
        }

        private void drawControls(Canvas c, float w, float h) {
            float y=h-dp(48);
            p.setColor(Color.argb(70,255,255,255)); p.setStrokeWidth(dp(4));
            c.drawLine(dp(28),y,w-dp(28),y,p);
            float displayAngle = manual ? manualAngle : rawAngle;
            float sx=dp(28)+(w-dp(56))*(displayAngle/180f);
            p.setColor(Color.WHITE); c.drawCircle(sx,y,dp(8),p);
            text.setTextSize(dp(10)); text.setAlpha(155); text.setColor(Color.WHITE);
            c.drawText("0°",dp(28),y-dp(13),text); c.drawText("180°",w-dp(58),y-dp(13),text);
            text.setAlpha(130);
            c.drawText(manual ? "sleep = handmatig • tik bovenaan = live" : "sleep = handmatig • tik midden = debug", dp(28), h-dp(18), text);
        }

        float dp(float v){ return v*getResources().getDisplayMetrics().density; }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float h=getHeight(), w=getWidth();
            if (e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                if (e.getY()>h-dp(100)) {
                    manual=true;
                    float a=((e.getX()-dp(28))/(w-dp(56)))*180f;
                    setManualAngle(a);
                    return true;
                }
            }
            if (e.getAction()==MotionEvent.ACTION_UP) {
                if (e.getY()<dp(115) && sensorAvailable) {
                    manual=false;
                    frozen=false;
                    lastSensorNs=0L;
                    invalidate();
                    return true;
                }
                if (e.getY()>dp(115) && e.getY()<h-dp(105)) {
                    showDebug=!showDebug;
                    invalidate();
                    return true;
                }
            }
            return true;
        }
    }
}
